#!/bin/bash
# Nightly backup of the shop data folder
BACKUP_DIR=/backups/$1
DATA_DIR=/var/shop/data

mkdir -p $BACKUP_DIR
cp -r $DATA_DIR/* $BACKUP_DIR/
rm -rf /backups/$2
echo "backup done"
