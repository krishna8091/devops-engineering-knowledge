# shopeasy-infra (practice repo, made-up data)

Infrastructure files for a made-up online shop called ShopEasy.

- terraform/  : AWS resources (a server and a storage bucket)
- k8s/        : Kubernetes file for the shop-api app
- docker/     : Dockerfile to build the shop-api image
- scripts/    : a nightly backup script
- .github/    : a pipeline that deploys on every push to main

All values are fake. Do not use this in a real account.
