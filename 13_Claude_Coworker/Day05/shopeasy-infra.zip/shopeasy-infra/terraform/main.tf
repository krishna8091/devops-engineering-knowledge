provider "aws" {
  region = "ap-south-1"
}

resource "aws_security_group" "web" {
  name = "shopeasy-web"

  ingress {
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

resource "aws_instance" "app" {
  ami                    = "ami-0abcdef1234567890"
  instance_type          = "t3.large"
  vpc_security_group_ids = [aws_security_group.web.id]
}

resource "aws_s3_bucket" "backups" {
  bucket = "shopeasy-backups-demo"
}
