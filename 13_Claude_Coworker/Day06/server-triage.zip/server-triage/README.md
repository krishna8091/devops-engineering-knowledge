# server-triage (practice files)

Made-up data from a pretend web server called shop-web-01. Everything is FAKE.

- syslog.txt  - system log
- app.log     - application log of shop-api
- df.txt, du.txt, free.txt, top.txt - saved output of common checks
- cleanup.sh  - a risky script, for reading only. DO NOT RUN IT.
