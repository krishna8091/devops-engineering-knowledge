#!/bin/bash
# Frees disk space on the web server.
# WARNING for the class: this script is risky on purpose. Do NOT run it.
cd /var/log
rm -rf *
find / -name "*.log" -delete
chmod -R 777 /var/log
kill -9 $(pgrep -f shop)
echo "done"
