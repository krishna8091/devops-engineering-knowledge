# Runbook: restart shop-api safely (manual steps)

1. Check the service: systemctl status shop-api
2. Check free disk space: df -h
3. Copy the config as a backup: cp /etc/shop/api.conf /etc/shop/api.conf.bak
4. Restart: systemctl restart shop-api
5. Look at the last 20 log lines: journalctl -u shop-api -n 20
6. Confirm the site answers: curl -s -o /dev/null -w "%{http_code}" http://localhost:8080/health
