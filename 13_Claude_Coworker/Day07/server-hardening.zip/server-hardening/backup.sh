#!/bin/bash
# Backup the shop data
tar czf /backups/shop-backup.tar.gz /var/lib/shop
scp /backups/shop-backup.tar.gz backup@10.0.0.9:/data/
rm -rf /backups/*
