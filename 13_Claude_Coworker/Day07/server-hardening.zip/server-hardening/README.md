# server-hardening (practice files)

Made-up files from a pretend server shop-web-01. Everything is FAKE.
We only read and write files here. Nothing runs on a server.

- shop-api.service  - a systemd service file (weak on purpose)
- backup.sh, crontab.txt - a backup script and its schedule (weak on purpose)
- ufw-status.txt, ports.txt - saved firewall and open-port output
- sshd_config.txt   - an SSH settings excerpt
- runbook.md        - manual steps to restart the service
